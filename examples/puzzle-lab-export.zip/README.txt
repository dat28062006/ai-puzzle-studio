AI Puzzle Studio
level.json: original level, importable into the app.
report.json: current play state and real search/policy metrics; search.start_state identifies the origin.
preview.png: current board. solution.gif: replay from the search origin, when solved.
assets: normalized tiles and generation prompts/provenance.
